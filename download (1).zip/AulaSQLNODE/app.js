const sqlite3=require('sqlite3').verbose();

//Conectar ao banco de dados (ou criar se não existe)
let db=new sqlite3.Database('./meu-banco.db', (err)=>{
    if(err){
        console.log(err.message);
    }else{
        console.log('Conectado ao banco de dados');
    }
});

//Criar uma Tabela - SQL

db.run(`CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    email TEXT NOT NULL
)`);

//Inserir dados na tabela

const sqlInsert=`INSERT INTO usuarios (nome, email) VALUES (?, ?)`;
db.run(sqlInsert,['João Silva','joao@email.com'],function(err){
    if(err){
        console.log(err.message);
    }else{
        console.log(`Usuário inserido com sucesso. ID: ${this.lastID}`);
    }
});

//Consultar dados
const sqlSelect=`SELECT * FROM usuarios`;
db.all(sqlSelect, [],(err, rows)=>{
    if(err){
        throw err;
    }
    rows.forEach((row)=>{
        console.log(row);
    });
});

//Fechar a conexão
db.close((err)=>{
    if(err){
        console.error(err.message);
    }else{
        console.log('Conexão com o banco de dados fechada');
    }
});

